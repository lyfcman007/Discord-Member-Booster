import asyncio
import aiohttp
import random
import time
from dotenv import load_dotenv
import os
load_dotenv()


async def changeName(token, loop, id_room):
    url = f"https://discord.com/api/v9/channels/{id_room}/messages"
    headers = {
		'Authorization': token,
	}
    Message = ["ข้อความ1", "ข้อความ2", "ข้อความ3", "ข้อความ4", "ข้อความ5"]
    async with aiohttp.ClientSession() as session:
        while True:
            data = {
			    "mobile_network_type": "wifi",
			    "content": random.choice(Message),
			    "nonce": "1159536968011" + str(random.randint(000000, 999999)),
			    "tts": "false",
			    "flags": 0
			}
            async with session.post(url, headers=headers, data=data) as response:
            	print(response.status)
            	time.sleep(int(loop))
            	




if __name__ == "__main__":
	token = os.environ.get("TOKEN")
	loop = os.environ.get("LOOP")
	id_room = os.environ.get("ID_ROOM")
	asyncio.run(changeName(token, loop, id_room))